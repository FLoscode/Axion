
class PolarFaultAnalyzer:
    def __init__(self, normal_data_path='data/normal_telemetry.csv'):
        # Establish a baseline for "Normal" behavior
        import pandas as pd
        df = pd.read_csv(normal_data_path)
        self.means = df[['rpm', 'temp']].mean()
        self.stds = df[['rpm', 'temp']].std()

    def analyze_fault(self, anomalous_data):
        """
        Identifies which specific sensor caused the anomaly.
        """
        explanation = []
        # Check each CHP unit in the telemetry
        for unit in anomalous_data['chp_units']:
            # Calculate how many standard deviations the current data is from the mean
            rpm_drift = (unit['rpm'] - self.means['rpm']) / self.stds['rpm']
            temp_drift = (unit['temp'] - self.means['temp']) / self.stds['temp']

            if abs(temp_drift) > 2.0:
                explanation.append(f"Unit {unit['id']}: Critical Temperature Drift ({unit['temp']:.1f}C). Likely Bearing Friction.")
            
            if abs(rpm_drift) > 2.0:
                explanation.append(f"Unit {unit['id']}: Unstable RPM detected ({unit['rpm']:.0f} RPM). Check fuel injectors.")

        return " | ".join(explanation) if explanation else "General System Instability detected."

if __name__ == "__main__":
    # Test case: Mock an anomaly
    mock_anomaly = {
        "chp_units": [{"id": 1, "rpm": 1505, "temp": 112.5}] # High temp
    }
    analyzer = PolarFaultAnalyzer()
    print(f"AI EXPLAINER: {analyzer.analyze_fault(mock_anomaly)}")
