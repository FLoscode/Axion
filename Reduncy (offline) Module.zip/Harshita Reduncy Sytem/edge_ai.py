import pickle
import numpy as np

class PolarEdgeAI:
    def __init__(self):
        with open('model/anomaly_model.pkl', 'rb') as f:
            self.model = pickle.load(f)

    def predict(self, rpm, temp):
        # -1 indicates an anomaly (latent defect) [7]
        prediction = self.model.predict([[rpm, temp]])
        return "CRITICAL" if prediction == -1 else "HEALTHY"
