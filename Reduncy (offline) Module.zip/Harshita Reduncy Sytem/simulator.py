import json
import random
import time

def generate_telemetry():
    # Simulating Bharati's 3 CHP units and Fuel Farm
    data = {
        "timestamp": time.time(),
        "station": "BHARATI",
        "chp_units": [
            {"id": i, "rpm": random.gauss(1500, 10), "temp": random.gauss(85, 2)}
            for i in range(1, 4)
        ],
        "fuel_farm": {"capacity_litres": 300000, "current_level": random.uniform(250000, 290000)},
        "sat_link_status": True
    }
    return data

if __name__ == "__main__":
    while True:
        print(json.dumps(generate_telemetry()))
        time.sleep(5)
