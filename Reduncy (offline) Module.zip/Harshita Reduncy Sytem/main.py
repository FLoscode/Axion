from edge_ai import PolarEdgeAI
from simulator import generate_telemetry
from local_logger import log_offline_event
import time

ai_brain = PolarEdgeAI()
SAT_LINK_ACTIVE = True
# Toggle this for your jury demo!

def run_system():
    while True:
        sensor_data = generate_telemetry()
        
        # Check for anomalies in CHP Unit 1
        chp1 = sensor_data['chp_units'][0]

        status = ai_brain.predict(
        chp1['rpm'],
        chp1['temp']
        )
        
        if status == "CRITICAL":
            if SAT_LINK_ACTIVE:
                print(f"ALARM: Sending alert to Goa HQ: "
                      f"{sensor_data}")
            else:
                log_offline_event(sensor_data)
        else:
            print("System Check: All life-support systems healthy.")
            
        time.sleep(5)

if __name__ == "__main__":
    run_system()
