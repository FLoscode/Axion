import sqlite3

def log_offline_event(event_data):
    conn = sqlite3.connect('data/offline_storage.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS delta_logs (data TEXT)''')
    c.execute("INSERT INTO delta_logs VALUES (?)", (str(event_data),))
    conn.commit()
    conn.close()
    print("Sat-Link Down: Event saved to Local Delta Log.")
