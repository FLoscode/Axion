import pandas as pd
from sklearn.ensemble import IsolationForest
import pickle

# Load your simulated normal data
data = pd.read_csv('data/normal_telemetry.csv') 

# Isolation Forest is excellent for unsupervised anomaly detection [8]
model = IsolationForest(contamination=0.01)
model.fit(data[['rpm', 'temp']])

# Save for offline edge use
with open('model/anomaly_model.pkl', 'wb') as f:
    pickle.dump(model, f)
print("Model trained and saved offline.")
